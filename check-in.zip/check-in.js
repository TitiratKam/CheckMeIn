
import React from 'react';
import {AsyncStorage, ScrollView, AppRegistry, StyleSheet, Text, View,Alert, TextInput, TouchableOpacity, 
    ImagePickerIOS, Image, KeyboardAvoidingView, StatusBar,Modal,Dimensions } from 'react-native';
var {height, width} = Dimensions.get('window');
import AnalogClock from './AnalogClock';
import DigitalClock from './DigitalClock';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {Icon,Button,Container,Header,Content,Left,Title,Body,Right} from 'native-base';
import firebase from './firebase';
import ImagePicker from 'react-native-image-picker';
import MapView from 'react-native-maps';

const options = {
        title: 'Select photo',
        takePhotoButtonTitle : 'Take a photo',
        chooseFromLibaryButtonTitle : 'Choose photo from libary',
        quality: 1
    };


export default class CheckIn extends React.Component {




    constructor(props) {
    super(props);
    this.database = firebase.database();
    this.state = {
      currentUser: [],
      User: [],
      image: null,
      chosenDate: new Date(),
      userid: [],
      hasToken:false,
      beacon: true,
      outside: false,
      latitude: null,
      longitude: null,
      date: null,
      time: null,
      timec: null,
      location: null,
      modalNoti: false,
       region: {
        latitude: 13.764884,
        longitude: 100.538265,
        latitudeDelta: 0.005,
        longitudeDelta: 0.005,
        },
        today:[]
    };
    //this.chooseImageFromGallery = this.chooseImageFromGallery.bind(this);
    //this.setDate = this.setDate.bind(this);
    //this.currentUser = this.database.ref('currentUser');
    //this.listeningForcurrentUser = this.listeningForcurrentUser.bind(this);
    //this.listeningForUser = this.listeningForUser.bind(this);
    this.chooseImageFromCamera = this.chooseImageFromCamera.bind(this);
    this.checkin = this.checkin.bind(this);
    this.outsideChecked = this.outsideChecked.bind(this);
    this.noti = this.noti.bind(this);
    this.onRegionChange = this.onRegionChange.bind(this);
    this.checkinCheck = this.checkinCheck.bind(this);
    this.checkinCheck1 = this.checkinCheck1.bind(this);
    this.checkinCheck2 = this.checkinCheck2.bind(this);
  }

    static navigationOptions = {
        title: 'CHECK-IN',
        headerLeft: null,
        tabBarLabel:'CHECK-IN',
        drawerIcon: ({tintColor}) => {
            return (
                <MaterialIcons
                name="access-time"
                size={24}
                style={{color: tintColor}}>
                </MaterialIcons>
                ///
                );
        }
    };

    componentDidMount() {
    var {navigate} = this.props.navigation;

    AsyncStorage.getItem('id').then((token) => {
      this.setState({ hasToken: token !== null, isLoaded: true })
      if (this.state.hasToken == true) {
        this.setState({ userid: token});
        console.log("id ="+ this.state.userid);
        this.AttendanceHis();
      }
        else{
            
            navigate("LogIn");
          }
    });



    //  AsyncStorage.multiGet(['id', 'reportto','f_name','l_name']).then((token) => {
    //   this.setState({ hasToken: token !== null, isLoaded: true })
    //   if (this.state.hasToken == true) {
    //     this.setState({ userid: token[0][1]});
    //     this.setState({ reportto: token[1][1]});
    //     this.setState({ f_name: token[2][1]});
    //     this.setState({ l_name: token[3][1]});
    //     console.log("id ="+this.state.userid);
    //     console.log("reportto ="+this.state.reportto);
    //   }
    //     else{
    //         }
    // });
}
    getCurrentTime = () =>
    {
        let hour = new Date().getHours();
        let minutes = new Date().getMinutes();
        let seconds = new Date().getSeconds();
        let date = new Date().getDate();
        let month = new Date().getMonth() + 1;
        let year = new Date().getFullYear();

        if( minutes < 10 )
        {
            minutes = '0' + minutes;
        }

        if( seconds < 10 )
        {
            seconds = '0' + seconds;
        }       

       
        this.setState({ time: hour + ':' + minutes});
        this.setState({ timec: hour + '.' + minutes});
        this.setState({ date: date + '-' + month + '-' + year});
        
        console.log('time' + this.state.timec);  
        console.log(this.state.date);
        this.checkinCheck1();    
    }

    outsideChecked() {

        fetch('http://192.168.1.50:8003/api/v1.0/checkin', {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userid : this.state.userid,
                date : this.state.date,
                time : this.state.time,
                picture : this.state.image,
                location : 'Outside',
                latitude : this.state.latitude,
                longitude : this.state.longitude,
        //       username: this.state.username,
        //       password: this.state.password,
            })
          })

            .then((response) => response.json())
            .then((responseData) => {
            //this.saveItem('id_token', responseData.id_token),
            //Alert.alert( 'Signup Success!', 'Click the button to get a Chuck Norris quote!'),
            //Actions.HomePage();
            console.log(responseData),
            this.setState({modalNoti:false});
            
            
          })
        //
          .done();
    }

    checkinCheck(){
        this.getCurrentTime();
        //this.checkinCheck1();


    }

    checkinCheck1(){
        fetch('http://192.168.1.50:8003/api/v1.0/checkinCheck', {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userid : this.state.userid,
                date : this.state.date,
                time : this.state.time,
        //       username: this.state.username,
        //       password: this.state.password,
            })
          })

            .then((response) => response.json())
            .then((responseData) => {
            //this.saveItem('id_token', responseData.id_token),
            //Alert.alert( 'Signup Success!', 'Click the button to get a Chuck Norris quote!'),
            //Actions.HomePage();
           // console.log(responseData[0]),
            this.setState({today : responseData}),
            console.log(this.state.today),
            this.checkinCheck2();

            
            
          })
        //
          .done();   

    }

    checkinCheck2(){
        let today = this.state.today;
        console.log(today.length);
        if (today.length == 0){
            this.noti();  
            }
        else if (today.length ==1 && this.state.timec < 14.00){
            Alert.alert("You have check-in already.");
        }
        else if (today.length ==1 && this.state.timec > 14.00){
            this.noti(); 
        }
        else{
            Alert.alert("You have check-out already.");
        }    

    }

    
    checkin() {
    
    if (this.state.beacon == true){
        this.getCurrentTime();
        this.chooseImageFromCamera();
    }

    else if (this.state.outside == true){
        
        navigator.geolocation.getCurrentPosition(
       (position) => {
         console.log("checkin outside");
         //console.log(position);
         this.setState({
           latitude: position.coords.latitude,
           longitude: position.coords.longitude,

           //error: null,
         });
         this.setState({
           region:{latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                latitudeDelta: 0.005,
                longitudeDelta: 0.005,}

           //error: null,
         });
         console.log("location w longitude : " + this.state.longitude + " latitude : " + this.state.latitude);
         this.getCurrentTime();
         //this.outsideChecked();
         this.state.checkinCheck1();
        //this.noti();
       },
       (error) => this.setState({ error: error.message }),
       { enableHighAccuracy: false, timeout: 200000, maximumAge: 1000 },
        );
        
         //Alert.alert('Success');
        
    }
    else{
        Alert.alert('You are not in location');
    }
    }




    chooseImageFromCamera() {
    ImagePickerIOS.openCameraDialog({}, imageUri => {
      this.setState({image: imageUri});
      
      //console.log(imageUri.edges);

      console.log(this.state.image);
      //this.saveItem(this.state.image);

      fetch('http://192.168.1.50:8003/api/v1.0/checkin', {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userid : this.state.userid,
                date : this.state.date,
                time : this.state.time,
                picture : this.state.image,
                location : this.state.location,
                latitude : this.state.latitude,
                longitude : this.state.longitude,
        //       username: this.state.username,
        //       password: this.state.password,
            })
          })

            .then((response) => response.json())
            .then((responseData) => {
            //this.saveItem('id_token', responseData.id_token),
            //Alert.alert( 'Signup Success!', 'Click the button to get a Chuck Norris quote!'),
            //Actions.HomePage();
            console.log(responseData),
            
            Alert.alert('Success');
            
          })
        //
          .done();
    }, error => console.error(error));
  }

        noti(){
  
         this.setState({modalNoti:true});

          }
          back(){
          
             this.setState({modalNoti:false});

          }


          onRegionChange(region) {
                this.setState({ region });
            }


        // listeningForUser() {
        // this.User.on('value', (snapshot) => {
        //   console.log("User:", snapshot.val());
        //   this.setState({
        //     User: snapshot.val() || []
        //   });
        // })

        // console.log(this.state.User);

        // }

  // componentDidMount() {
  //   this.listeningForcurrentUser();
  // }

    render() {
        return (
            

               <Container>
                    <Header>
                        <Left>
                            <Icon name="ios-menu" onPress={() =>
                                this.props.navigation.navigate('DrawerOpen')}/>
                        </Left>
                        <Body  style={styles.body}>
                            <Title>CheckMeIn</Title>
                        </Body>
                        <Right>
                        </Right>
                    </Header>

                <Modal
              state={styles.modal}
              visible={this.state.modalNoti}
              animationType={'slide'}
              onRequestClose={() => this.closeModal()}
             >
             
              <Container>
                <Header>
                <Left>
                   <TouchableOpacity onPress = {() => this.back()}>
                    <Text>
                        Back
                    </Text>
                   </TouchableOpacity>
                </Left>
               
                </Header>

                <Content>
                <MapView style={styles.map}
                              region={this.state.region}
                              onRegionChange={this.onRegionChange}
                            >

                            <MapView.Marker
                               coordinate={{latitude: this.state.latitude, longitude: this.state.longitude}}
                               title="Victory Monument"
                               description="A large military monument in Bangkok, Thailand."
                             />
                    </MapView>

                    <View style={styles.formContainer}>
                     <View style={styles.db3}>
                      
                      <Text style={styles.modaltext}>Date : {this.state.date}</Text>
                      <Text style={styles.modaltext}>Time : {this.state.time}</Text>
                      <Text style={styles.modaltext}>Location : {this.state.latitude}</Text>
                      <Text style={styles.modaltext}>                  {this.state.longitude}</Text>
                    </View>
                        <View style={styles.formButton}>
                            <View style={styles.db}>
                                <TouchableOpacity style={[styles.button,{backgroundColor: 'rgb(0, 153, 115)'}]}  onPress = {() => this.outsideChecked()}>
                                    <Text style={styles.Approve}>
                                      Confirm
                                    </Text>
                            
                                </TouchableOpacity>
                            </View> 
                        </View>
                    </View>
                </Content>
              </Container>
             </Modal>


                    <Content ContentContainerStyle={{
                        flex:1,
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}>
                        <View style={styles.DigitalClock}>

                                 <DigitalClock />

                        </View>
                        <View style={styles.formContainer}>
                            <TouchableOpacity style={[styles.button,{backgroundColor: '#e59400'}]}  onPress={this.checkin}>
                                <Text style={styles.textBtn}>CHECK IN</Text>
                            </TouchableOpacity>

                        </View>

                        <View style={{flex: 1}}>
                            {this.state.image?
                            <Image style={{flex: 1}} source={{uri: this.state.image}}></Image>:null}
                        </View>

                    </Content>
                 </Container>
            
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        //backgroundColor: 'rgba(175, 214, 240,1.0)',
    },
    logoContainer: {
        alignItems: 'center',
        flexGrow: 1,
        justifyContent: 'center',
        marginTop: 40
    },
    body: {
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        height: 100,
        width: 100
    },
    title: {
        color: '#FFF',
        width: 160,
        textAlign: 'center',
        opacity: 0.9,
        fontSize: 15
    },
    textBtn: {
        fontSize: 15,
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700'
    },
    button: {
        paddingVertical: 10,
        marginVertical: 5
    },
    input: {
        height: 40,
        backgroundColor: 'rgba(255, 255, 255,0.2)',
        marginBottom: 10,
        color: '#FFF',
        paddingHorizontal: 10
    },
    formContainer: {
        flex:1,
        padding: 20,
        marginBottom:100
    },
    DigitalClock: {
        flex:2,
        paddingTop: 100,
        marginBottom:100
    },
    db3:{
    flex:1,
    padding:10
  },
  detail:{
    textAlign:'right',
    color:'white',
    fontSize:13,
    padding:5
  },
  hdetail:{
    textAlign:'right',
    fontSize: 15,
    color: '#fff',
    fontWeight: '700',
    marginBottom: 10
  },
  hmodaltext:{
    textAlign:'center',
    fontSize: 25,
    color: '#000',
    fontWeight: '700',
    marginBottom: 10
  },
  modaltext:{
    textAlign:'left',
    color:'#000',
    fontSize:15,
    padding: 5
  },
  Approve: {
        fontSize: 15,
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700',

    },
    Deny: {
        fontSize: 15,
        color: '#fff',
        textAlign: 'center',
        fontWeight: '700',

    },
    modalimg:{
      alignItems:'center',
    width:200,
    height:200,
    margin:20
    },
      map:{
    width: width,
    height: height/2
}

});